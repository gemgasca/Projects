//
// Created by Gem Gasca on 2019-04-14.
//

#ifndef RPS_ROCKPAPERSCISSORS_H
#define RPS_ROCKPAPERSCISSORS_H

#include <string>
#include <iostream>

bool contPlaying();
int getInput();
std::string getWord(int x);
int whoWins(int ai, int user);

#endif //RockPaperScissors_RockPaperScissors_H
