//
// Created by Gem Gasca on 2019-04-15.
//

#ifndef ROCKPAPERSCISSORS_RANDOM_H
#define ROCKPAPERSCISSORS_RANDOM_H

int randGenerator(const int& seed);

#endif //ROCKPAPERSCISSORS_RANDOM_H
