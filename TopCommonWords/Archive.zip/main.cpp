#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include "stringFunctions.h"
#include "TopCommonWords.h"
#include <tuple>

// Helped by Obeid 914143011
// accepts command line argument for file name
int main(int argc, char** argv) {
    std::ifstream f;                   // opens file specified in command line
    f.open(argv[1]);

    std::vector<std::string> vector;   // instantiates variables
    std::map<std::string, int> map;
    std::vector<std::tuple<int, std::string>> countsVector;

    vector = makeVector(f);            // initializes vector of file words (strings)
    map = makeMap(vector);             // initializes map of words (strings) to count (int)
    countsVector = getCounts(map);     // initializes vector that contains count, word tuples

    int numWords;                      // determines how many top words are to be printed
    if (argc == 2){
        numWords = 10;
    }
    else if ((argc > 2) && (std::stoul(argv[2]) < countsVector.size())){
        numWords = std::stoi(argv[2]);
    }
    else{
        numWords = countsVector.size();
    }

    printVector(countsVector, numWords);


    f.close();
    return 0;
}

// error in test case 10
// stayin_alive.txt
// 1.) These words appeared 7 times: {your}
// 2.) These words appeared 6 times: {coming, dawn, eyes, open, won't}
// 3.) These words appeared 5 times: {days, to, you}
// 4.) These words appeared 4 times: {as, don't, gone, i, new, rise, stay, there's, world}
// 5.) These words appeared 3 times: {alive, but, do, into, it's, just, leaves, look, nothing, side, sun, turn, we'll, whatever, with}
// 6.) These words appeared 2 times: {1, 2, break, colors, dreams, empty, fade, feel, leave, lights, man, mean, morning, move, my, no, on, our, rhythm, rush, shallow, there, these, tonight, train, truth, verse, way, where, will, you're}
// 7.) These words appeared 1 times: {all, been, bridge, by, cannot, close, day, engine, engines, for, forever, gasoline, gears, grow, heart, here, hold, i've, keeping, know, lies, life, light, like, of, outro, place, refrain, run, sometimes, things, thoughts, til, time, wait, waiting, watch, well, who, write}